A Pen created at CodePen.io. You can find this one at http://codepen.io/awalx/pen/wKKvrz.

 Local weather forecast website using JQuery, Bootstrap and Forecast.io API.